Thank you for downloading this simple yet useful pack of two servo motor mounts by TERRN.DYNAMICS

These have been tested on the MG90S and SG90 servo motors, both fitting as intended. I am not sure
what other specific models of servo motors these mounts are compatible with but if you have any
suggestions to further mounts or other questions, please get in touch.

Please, use the blueprints provided to get accurate hole placements.

And lastly, I hope these two models will be found useful to you, and I wish you a lovely rest of your day.

All 3D models, instructions, and other assets created by TERRN.DYNAMICS remain under our copyright. 
This means you cannot distribute the original or modified assets without our permission. 
Thank you for respecting our rights.
